


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import java.util.NoSuchElementException;



public class TFIDF {

    public static void main(String[] args) throws Exception {

    	Connection c = null;
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		
		float tf = 0;
		float idf = 0;
		float idfqtd = 0;
		float tfidf = 0;
		float idflogdiv = 0;
		int QtdCorpus = 0;
    	
	//	System.out.println("------INICIO CONEX�O POSTGRES");
	    
		   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		    //  System.out.println("---------Conectado com Sucesso");
	          stmt = c.createStatement();
	          stmt2 = c.createStatement();
	          stmt3 = c.createStatement();
	          stmt4 = c.createStatement();
	          
	        //  System.out.println("---------Limpeza da tabela TF-IDF");
	          String sqldeletestgtfidf = "DELETE from stgtfidf";
	          stmt.executeUpdate(sqldeletestgtfidf);
	          c.commit();
          
	          
	          
	
	          
	          // Seleciona a Quantidade de Documentos no corpus
	          
	          ResultSet rsqry3 = stmt3.executeQuery( "select count(distinct id_artigo) as QtdCorpus from stganotacao;");
	         
	          if (rsqry3.next() == false) {
	        //	  System.out.println("---N�O H� CORPUS PARA CALCULO TF-IDF");
	          }
	          else {
	        	
	        //  System.out.println("---------Inicio do c�lculo TF");
	        	  
	          QtdCorpus = rsqry3.getInt("QtdCorpus"); 
	          rsqry3.close();
	          
	          
	          // Seleciona os Artigos e a quantidade de conceitos presentes no documento
	          
	         
	          // Considera todos os conceitos da anota��o desconsiderando os sinonimos dos conceitos
	          
	          ResultSet rsqry = stmt.executeQuery( "select artigo,  count(idclasse) as QtdConceitos  from (select id_artigo as artigo,  idclasse, termo from stganotacao s,  stgontologia o WHERE s.idclasse = o.termo_id and trim(lower(s.termo)) = trim(lower(o.termo_label)) union select id_artigo as artigo,  idclasse, termo from stganotacao s WHERE s.idclasse not in (select termo_id from stgontologia)) stganotacao group by artigo order by artigo  asc;");
	          
	          if (rsqry.next() == false) {
	          //    System.out.println("---N�O H� ARTIGOS NA LISTA");
	          } else {
	        	  
				  
	        	  do {
	        		 
	        		  String artigo = rsqry.getString("artigo");
	        		  Integer QtdConceitos = rsqry.getInt("QtdConceitos"); 
	        		  
	        		  // Seleciona a quantidade de cada conceito em um documento
	        		  
	        		  ResultSet rsqry2 = stmt2.executeQuery( "select artigo, idclasse as idconceito, count(*) as QtdConc from (select id_artigo as artigo,  idclasse, termo from stganotacao s,   stgontologia o WHERE s.idclasse = o.termo_id and trim(lower(s.termo)) = trim(lower(o.termo_label)) union select id_artigo as artigo,  idclasse, termo from stganotacao s WHERE s.idclasse not in (select termo_id from stgontologia) ) stganotacao where artigo = '" + artigo + "' group by artigo, idclasse order by artigo, idclasse asc;");
	        		  
	        		  if (rsqry2.next() == false) {
	    	           //   System.out.println("---N�O H� DOCUMENTOS NA LISTA");
	    	          } else {
	    	        	  
	    	        	  	do {
	    	    
	    	        	  		String conceito = rsqry2.getString("idconceito");
	    		        		float QtdConc = rsqry2.getInt("QtdConc");
	    		        		
	    		        		tf = (float) QtdConc / QtdConceitos;
	    		
	    						// Seleciona a quantidade de documentos do corpus onde o conceito est� presente/anotado.
	    						 
	    		        		ResultSet rsqry4 = stmt4.executeQuery( "select count(distinct id_artigo) as Qtdartigo from stganotacao where idclasse = '" + conceito + "';");
	    		
	    		        		if (rsqry4.next() == false) {
	    		        			tfidf = 0;
	    		        		}else{
	    		        			idfqtd = rsqry4.getInt("Qtdartigo");
	    		        		
		    		  	            idflogdiv = (float) QtdCorpus / idfqtd;
		    		  	        
	    		        			idf = (float) (Math.log(idflogdiv)/Math.log(2));
		    		  	            tfidf = (float) (tf * idf);
		    		  	          
	    		        		}
	    		        		rsqry4.close();
	    		        		
	    		        		String sql = "insert into stgtfidf (artigo, conceito, tf, idf, tfidf) VALUES (?, ?, ?, ?, ?)";
	    	        	  	    
	    		        		PreparedStatement pstm1 = c.prepareStatement(sql);
	    	        	  		
	    	        			pstm1.setString(1,artigo);
	    	        			pstm1.setString(2,conceito);
	    	        			pstm1.setFloat(3,tf);
	    	        			pstm1.setFloat(4,idf);
	    	        			pstm1.setFloat(5,tfidf);
	    	        			
	    	        			pstm1.execute();
	    	        			c.commit();
	    	        			pstm1.close();
	    	        		  
	    	        	  	} while (rsqry2.next() != false);
	    	        	  
	    	          		}  
	        		 
	        		  rsqry2.close();
	        		 
	        		  
	        		  
	        		  
	        		  
	                 } while (rsqry.next() != false);
	          
	        	
	 	      }	
	          rsqry.close();
	          
	        //  System.out.println("---------Fim do c�lculo TF");
	         
	          
	          }
	         

	    } catch (NoSuchElementException e) {
			}


	 //   System.out.println("------FIM CONEX�O POSTGRES");
	    
    }	
	
	
	
	
}
