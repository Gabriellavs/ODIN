

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import org.apache.log4j.PropertyConfigurator;


public class Hierarquia {

	public static void hierarquia(String name, String nomeonto, String linkconceito, String prefixo)  throws Exception {
	
		
		int Contador = 0;
		
		
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		
	    //System.out.println("---INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		     // System.out.println("Conectado com Sucesso");
	          stmt = c.createStatement();
	          
	               
	         
	          // INICIO SELECIONA SUPERCLASSE DOS TERMOS------------------------------------------------------------------------
	          
	          
	          
	          stmt2 = c.createStatement();
	          
	          ResultSet rsqry2 = stmt2.executeQuery( "  SELECT DISTINCT stg.termo_id,  stg.termo_label, stg.superclass_id AS SUPERCLASS  FROM stgontologia stg where (stg.ontologia = '" + name + "') and  (stg.superclass_id <> 'RAIZ' AND stg.superclass_id IS NOT NULL) AND (stg.superclass_id NOT IN (SELECT termo_id  FROM stgontologia where stg.ontologia = '" + name + "')) and stg.superclass_id NOT IN (SELECT conceito FROM stgconceito) ORDER BY stg.superclass_id");
	         
	          	
	     
			  if (rsqry2.next() == true)  {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  
	        			  
	        			  String termo_id = rsqry2.getString("termo_id");
	        			  String conceitolbl = rsqry2.getString("termo_label");
	        			  String termo = rsqry2.getString("SUPERCLASS");
	        			  
	        			  //String consulta = ("  SELECT DISTINCT stg.termo_id, stg.superclass_id AS SUPERCLASS  FROM stgontologia stg where (stg.termo_id = '" + termo_id + "' AND stg.superclass_id = '" + termo + "') AND (stg.superclass_id <> 'RAIZ' AND stg.superclass_id IS NOT NULL) AND (stg.superclass_id NOT IN (SELECT termo_id  FROM stgontologia)) ORDER BY stg.superclass_id");
	        			 
	        			  
	        			  
	        			//  System.out.println("Anotando SUPERCLASS:" + termo);
	        			  Contador ++;
	        			  
	        			 
	        			  
	        			 // System.out.println("Abriu conexao: " + Contador + " Termo/Pai: " + termo_id + " - " + termo);
	        			  ExtraiConceito anotacao = new ExtraiConceito();
	        		  	  anotacao.anota(termo, conceitolbl, name, nomeonto, linkconceito, prefixo);
	        		  	//		System.out.println("PASSO2");
	        		  	/*		
	        		  		 stmt3 = c.createStatement();
	        			     ResultSet rsqry3 = stmt3.executeQuery( "  select termo_id, superclass_id from stgontologia where  termo_id = '" + termo + "' AND superclass_id <> 'RAIZ';");
	        			     
	        			     if (rsqry3.next() == true)  {
       			        	  
       			        	  do {
       			        		  try {	
       			        			  	System.out.println("Abriu Hierarquia para a SuperClasse : " + termo );
       			        			  	hierarquia(nomeonto, linkconceito, prefixo);
       			        			  	System.out.println("Fechou Hierarquia para a SuperClasse : " + termo );		
       		  	
       			        		  }  catch (SQLException e) {
       			            			System.out.println("---ERRO NA EXTRA��O DE SUPERCLASSE 2");
       			            			e.printStackTrace();
       			            			return;
       			            			
       			        		  }
       			        	   
	        			     }   while (rsqry3.next() != false);
       			        	  
	        			     }
	        			     */
	        		  }  catch (SQLException e) {
	            		//	System.out.println("---ERRO NA EXTRA��O DE SUPERCLASSE 1");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                		//System.out.println(sql);
	                		
	                      } while (rsqry2.next() != false);
	          
	 	      }	
	   
			  //System.out.println("QTD de registros TERMOS selecionados: " + Contador);
			  rsqry2.close();
	          stmt2.close();
	          stmt.close();
	          c.close();  
	          //System.out.println("------FIM EXTRACAO SUPERCLASSES");
	          
	          
	          // FIM SELECIONA SUPERCLASSE DOS TERMOS--------------------------------------------------------------------
	          
		 
     

          // FECHANDO CONEX�ES 
          
          
     
	    }  catch (SQLException e) {
		//	System.out.println("---ERRO NA EXTRA��O DA HIERARQUIA");
			e.printStackTrace();
			return;
  	  	}
	    
	  catch (NoSuchElementException e) {
		}
	    
}

	
	public static boolean existe(String name, String termo_verifica, String super_verifica)  throws Exception {
	
		
		boolean result = false; 
		//PropertyConfigurator.configure("C:/Users/pc/workspace/JENA/src/log4j.properties");
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		Statement stmt3 = null;
		
	   	    
	    //System.out.println("---INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		     // System.out.println("Conectado com Sucesso");
	          stmt3 = c.createStatement();
	          
	               
	         
	          // INICIO SELECIONA SUPERCLASSE DOS TERMOS------------------------------------------------------------------------
	          
	          
	          
	          stmt3 = c.createStatement();
	          //ResultSet rsqry = stmt.executeQuery( "SELECT DISTINCT IDCLASSE FROM STGANOTACAO WHERE IDCLASSE IN ('IMR_0000651','IMR_0000947','IMR_0000967','IMR_0001348','IMR_0001349','IMR_0001350','IMR_0001351','IMR_0001352','IMR_0001354','IMR_0001355','IMR_0001356','IMR_0001357','IMR_0001358','IMR_0001359','IMR_0001360','IMR_0001361','IMR_0001362','IMR_0001381','IMR_0001382','IMR_0001383','IMR_0001384','IMR_0001385','IMR_0001650','IMR_0001651','IMR_0001655','IMR_0001657','IMR_0001658','IMR_0001693','IMR_0001694','IMR_0001695','IMR_0001697','IMR_0001698','IMR_0001699','IMR_0001700','IMR_0001720','IMR_0001789','IMR_0001790') ORDER BY IDCLASSE");
	          ResultSet rsqry3 = stmt3.executeQuery( "  SELECT DISTINCT stg.ontologia, stg.termo_id, stg.superclass_id AS SUPERCLASS  FROM stgontologia stg where ontologia = '" + name + "' and (stg.termo_id = '" + termo_verifica + "' AND stg.superclass_id = '" + super_verifica + "') ");
	        
	          result = rsqry3.next();
	          	     
			  
			 
			  
			  //System.out.println("QTD de registros TERMOS selecionados: " + Contador);
	          c.commit();
	          rsqry3.close();
	          stmt3.close();
	          c.close();  
	          //System.out.println("------FIM EXTRACAO SUPERCLASSES");
	          
	          
	          // FIM SELECIONA SUPERCLASSE DOS TERMOS--------------------------------------------------------------------
	          
		 
     

          // FECHANDO CONEX�ES 
          
          
     
	    } 
	    
	    catch (SQLException e) {
			System.out.println("---ERRO NA EXTRA��O DA HIERARQUIA");
			e.printStackTrace();
			
  	  	}
	    
	 
	    
	  catch (NoSuchElementException e) {	}
	    
	    return result;
	    
}
	
/////////////////////////////////////////////////////////////////////////////////////////////
	
	public static boolean existeonto(String name, String termo_verifica, String super_verifica)  throws Exception {
	
		
		boolean result = false; 
		//PropertyConfigurator.configure("C:/Users/pc/workspace/JENA/src/log4j.properties");
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		Statement stmt4 = null;
		
	   	    
	    //System.out.println("---INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		     // System.out.println("Conectado com Sucesso");
	          stmt4 = c.createStatement();
	          
	               
	         
	          // INICIO SELECIONA SUPERCLASSE DOS TERMOS------------------------------------------------------------------------
	          
	          ResultSet rsqry4 = stmt4.executeQuery( "  SELECT DISTINCT ontologia, termo, termopai FROM stgdimontologica where ontologia = '" + name + "' and (termo = '" + termo_verifica + "' AND termopai = '" + super_verifica + "') ");
	        
	          //String x = ( "  SELECT DISTINCT imr, imrpai FROM dimchemical where (imr = '" + termo_verifica + "' AND imrpai = '" + super_verifica + "') ");
	          result = rsqry4.next();
	          	     
			  
			 
			  
			  //System.out.println("QTD de registros TERMOS selecionados: " + Contador);
			  c.commit();
	          rsqry4.close();
	          stmt4.close();
	          c.close();  
	          //System.out.println("------FIM EXTRACAO SUPERCLASSES");
	          
	          
	          // FIM SELECIONA SUPERCLASSE DOS TERMOS--------------------------------------------------------------------
	          
		 
     

          // FECHANDO CONEX�ES 
          
          
     
	    } 
	    
	    catch (SQLException e) {
			System.out.println("---ERRO NA EXTRA��O DA HIERARQUIA");
			e.printStackTrace();
			
  	  	}
	    
	 
	    
	  catch (NoSuchElementException e) {	}
	    
	    return result;
	    
}
	
	
/////////////////////////////////////////////////////////////////////////////////////////////
	
	public static void dimontologica(String name, String pai)  throws Exception {
	//CARREGA STGDIMENS�O ONTOLOGICA
		
		
		//PropertyConfigurator.configure("C:/Users/pc/workspace/JENA/src/log4j.properties");
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		Statement stmt = null;
		Statement stmt2 = null;
	   	    
	    //System.out.println("---INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		     // System.out.println("Conectado com Sucesso");
	          stmt = c.createStatement();
	          
	               
	         
	          // INICIO SELECIONA SUPERCLASSE DOS TERMOS------------------------------------------------------------------------
	                   
	          
	          stmt2 = c.createStatement();
	          //ResultSet rsqry = stmt.executeQuery( "SELECT DISTINCT IDCLASSE FROM STGANOTACAO WHERE IDCLASSE IN ('IMR_0000651','IMR_0000947','IMR_0000967','IMR_0001348','IMR_0001349','IMR_0001350','IMR_0001351','IMR_0001352','IMR_0001354','IMR_0001355','IMR_0001356','IMR_0001357','IMR_0001358','IMR_0001359','IMR_0001360','IMR_0001361','IMR_0001362','IMR_0001381','IMR_0001382','IMR_0001383','IMR_0001384','IMR_0001385','IMR_0001650','IMR_0001651','IMR_0001655','IMR_0001657','IMR_0001658','IMR_0001693','IMR_0001694','IMR_0001695','IMR_0001697','IMR_0001698','IMR_0001699','IMR_0001700','IMR_0001720','IMR_0001789','IMR_0001790') ORDER BY IDCLASSE");
	          ResultSet rsqry2 = stmt2.executeQuery( "SELECT id, termo, conceito, termopai FROM stgdimontologica where ontologia = '" + name + "' and termo = '" + pai + "' ORDER BY termo");
	         //String x = "SELECT id, imr, nome, idchemicalpai, imrpai FROM dimchemical where imr = '" + pai + "' ORDER BY imr";
	          	
	     
			  if (rsqry2.next() == true)  {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  
	        			  //System.out.println(rsqry.getString("IDCLASSE"));
	        			  String idtermopai = rsqry2.getString("id");
	        			  String termo = rsqry2.getString("termo");
	        			  String conceito = rsqry2.getString("conceito");
	        			  String termopai = rsqry2.getString("termopai");
	        			  
	        			  //System.out.println("---QUIMICO PAI: " + idchemical + " - " + imrchemical + " - " + chemical_label + " - " + imrchemicalpai);
	        			  
	        			  
	        			  ResultSet rsqry3 = stmt.executeQuery("SELECT c.id as idpai, c.termo as termopai, o.termo_id as termofilho, o.termo_label as conceitofilho FROM stgdimontologica c , stgontologia o where (c.ontologia = '" + name + "' and o.ontologia = '" + name + "') and c.termo = o.superclass_id and c.termo = '" + termo + "'");
	        			  
	        			  if (rsqry3.next() == true)  {
	        	        	  
	        	        	  do {
	        	        		  try {
	        	        			  
	        	        			  int idpaiinsere = rsqry3.getInt("idpai");
	        	        			  String termopaiinsere = rsqry3.getString("termopai");
	        	        			  String termofilhoinsere = rsqry3.getString("termofilho");
	        	        			  String conceitofilhoinsere = rsqry3.getString("conceitofilho");
	        	        			  
	        	        			  
	        	        			  Hierarquia.existeonto(name, termofilhoinsere, termopaiinsere);////////////////////////////
	        	      		  		
	        	        			  if (Hierarquia.existeonto(name, termofilhoinsere, termopaiinsere)  == false )  { 	/////////////////////////////
	        	        			  
	        	        			  //System.out.println("---QUIMICO FILHO: " + idpaiinsere + " - " + termopaiinsere + " - " + imrfilhoinsere + " - " + nomefilhoinsere);
	        	        			  
	        	        			  
	        	        			  String sql = "INSERT INTO stgdimontologica (termo, conceito, idtermopai, termopai, ontologia) VALUES (?, ?, ?, ?, ?)";
	      	        	      	    
	        	        			  PreparedStatement pstm = c.prepareStatement(sql);
	      	        	      		
	      	        					pstm.setString(1,termofilhoinsere);
	      	        					pstm.setString(2, conceitofilhoinsere);
	      	        					pstm.setInt(3, idpaiinsere);
	      	        					pstm.setString(4, termopaiinsere);
	      	        					pstm.setString(5, name);
	      	        				
	      	        				
	      	        					pstm.execute();
	      	        					c.commit();
	      	        					pstm.close();
	      	        					
	      	        					Hierarquia.dimontologica(name, termofilhoinsere);
	      	        					
	        	        			  	}
	        	        			  
	        	        		  }  
	        	        		  
	        	        		  catch (SQLException e) {
	      	            			System.out.println("---ERRO NA INCLUS�O DOS FILHOS");
	      	            			e.printStackTrace();
	      	            			return;
	      	              	  		}
	      	                		
	      	                		//System.out.println(sql);
	      	                		
	      	                      } while (rsqry3.next() != false);  
	        	        		  }
	        			 // System.out.println("SUPERCLASS:" + termo);
	        			 // Contador ++;
	        			  
	        			 
	        			 /* 
	        			  String sql = "INSERT INTO dimchemical (imr, nome, idchemicalpai, imrpai) VALUES (?, ?, ?, ?)";
	        	      	    
	        	      		PreparedStatement pstm = c.prepareStatement(sql);
	        	      		
	        				pstm.setString(1,idchemical);
	        				pstm.setString(2, chemical_label);
	        				pstm.setInt(3, 0);
	        				pstm.setString(4, imrchemicalpai);
	        				//pstm.setString(5, superclass_link);
	        				
	        				
	        				pstm.execute();
	        				c.commit();
	        				pstm.close();
	        		  			
	        		  	*/
	        			  
	        	         	    		
	        		  }  catch (SQLException e) {
	            			System.out.println("---ERRO NA MONTAGEM DA HIERARQUIA");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                		//System.out.println(sql);
	                		
	                      } while (rsqry2.next() != false);
	          
	 	      }	
	   
			  //System.out.println("QTD de registros TERMOS selecionados: " + Contador);
			  c.commit();
			  rsqry2.close();
	          stmt2.close();
	          c.close();  
	          //System.out.println("------FIM EXTRACAO SUPERCLASSES");
	          
	          
	          // FIM SELECIONA SUPERCLASSE DOS TERMOS--------------------------------------------------------------------
	          
		 
     

          // FECHANDO CONEX�ES 
          
          
     
	    }  catch (SQLException e) {
			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOL�GICA");
			e.printStackTrace();
			return;
  	  	}
	    
	  catch (NoSuchElementException e) {
		}
	    

	    
	}		
	
	
	
}
