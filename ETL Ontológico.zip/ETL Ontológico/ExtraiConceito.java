


import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;

import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.util.FileManager;
import org.apache.log4j.PropertyConfigurator;


import org.apache.jena.query.Dataset;

import org.apache.jena.query.ReadWrite;

import org.apache.jena.rdf.model.Literal;
import org.apache.jena.tdb.TDBFactory;
import org.apache.jena.tdb.TDBLoader;
import org.apache.jena.tdb.base.file.Location;
import org.apache.jena.tdb.sys.TDBInternal;

public class ExtraiConceito {

	public static void anota(String termo, String conceitolbl, String name, String nomeonto, String linkconceito, String prefixo) {
		
	try {
 
		final String inputFileName = nomeonto;
		
		int contador2 = 0;

		Connection c = null;
		   
		Statement stmt = null;
		Statement stmt1 = null;
		    
	//	PropertyConfigurator.configure("C:/Users/pc/workspace/DimOntologica/src/log4j.properties");
		    
		Class.forName("org.postgresql.Driver");
		c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		c.setAutoCommit(false);
		
		stmt = c.createStatement();
		stmt1 = c.createStatement();    
		      
		OntModel base = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM, null);
		OntModel model = (OntModel) base.read(inputFileName);
		InputStream in = FileManager.get().open(inputFileName);
		
		
		
		if (in == null) {
			throw new IllegalArgumentException("File: " + nomeonto + " not found");
			}
		else{ 
			
			String SparqlQuery = prefixo  +
					   "SELECT DISTINCT ?subject ?label ?super " +
					   "WHERE { " +
					   "?subject a owl:Class . " +
					   "?subject rdfs:label ?label . " +
					   "FILTER ( ?subject = <" + linkconceito + termo +"> )" +
					 // "FILTER ( UCASE(str(?label)) = \"" + conceitolbl + "\")" +
					   "OPTIONAL { " +
					   "?subject rdfs:subClassOf ?super " +
					   " }" +
					   " }order by ?subject";
			

			//System.out.println("SparqlQuery:" + SparqlQuery);
		        
		   
			Query query = QueryFactory.create(SparqlQuery);
	        QueryExecution qe = QueryExecutionFactory.create(query, model);
	        ResultSet results =  qe.execSelect();   
	        
	     
	        
	        if (results.hasNext() == false) {
	    		contador2++;
	    	//	System.out.println("N�o extra�do:" + conceitolbl);
	    		
	    		String sql1 = "INSERT INTO stgconceito (conceito) VALUES (?)";
		  	    
		  		PreparedStatement pstm1 = c.prepareStatement(sql1);
		  		pstm1.setString(1,termo);
		  		pstm1.execute();
				c.commit();
				pstm1.close();
				
				
	    		}
	    	else{ 
	    		
	    	
	    		
	        QuerySolution rs1 = results.next();
	        
	        /////////////////////////
	    
	       // System.out.println("LINHA ");
	        
	        RDFNode termolink1 = rs1.get("subject");
	    
	        RDFNode label1 = rs1.get("label") ;
	  		RDFNode superclasslink1 = rs1.get("super") ;
	  		String termo_link1 = termolink1.toString();
	  		String descricao1 = label1.toString();
	  		String[] stringDividida1 = termo_link1.split(linkconceito);
	  		
	  		String termo_id1 = stringDividida1[1];
	  		
	  		String superclass_link1;
	  		
	  		if (superclasslink1 == null)	{ superclass_link1 = linkconceito + "RAIZ";} else {superclass_link1 = superclasslink1.toString();}
	  		String[] stringDividida12 = superclass_link1.split(linkconceito);
	  		String superclass_id1; 
	  		if (stringDividida12.length == 1){superclass_id1 = "RAIZ"; } else { superclass_id1 = stringDividida12[1];};	
	  		
	  		//System.out.println("---Teste anotacao: " + termo_id1 + " - " + superclass_id1);
	  		
	  		//VERIFICA SE O TERMO E SUA SUPER CLASSE EXISTEM
	  		//System.out.println("---: " + termo_id1 + " - " + superclass_id1);
	  		Hierarquia.existe(name, termo_id1, superclass_id1);
	  		
	  		
	  		if (Hierarquia.existe(name, termo_id1, superclass_id1)  == false )  { 			
	  		
	  		//	System.out.println("---INSERINDO STGONTOLOGIA: " + termo_id1 + " - " + superclass_id1);
	  			
	  		//INSERE O REGISTRO
	  		String sql1 = "INSERT INTO STGONTOLOGIA (TERMO_ID, TERMO_LABEL, TERMO_LINK, SUPERCLASS_ID, SUPERCLASS_LINK, ONTOLOGIA) VALUES (?, ?, ?, ?, ?, ?)";
	  	    
	  		PreparedStatement pstm1 = c.prepareStatement(sql1);
	  		
			pstm1.setString(1,termo_id1);
			pstm1.setString(2, descricao1);
			pstm1.setString(3, termo_link1);
			pstm1.setString(4, superclass_id1);
			pstm1.setString(5, superclass_link1);
			pstm1.setString(6, name);
			
			//count++;
			
			pstm1.execute();
			c.commit();
			pstm1.close();
			
			
	    	
	        
	      //  System.out.println("---------------: "+ termo_link);
			
	        if (results.hasNext() == false) {
	        	contador2++;
	        }
	        
	        else{
	        	
	        
	        while( results.hasNext() ) 
	        { //	count++; 
	        //	  System.out.println("LINHA ");
	        QuerySolution rs = results.next();
	        
	       	
	        	RDFNode termolink = rs.get("subject");
		        RDFNode label = rs.get("label") ;
	      		RDFNode superclasslink = rs.get("super") ;
	      		String termo_link = termolink.toString();
	      		String descricao = label.toString();
	      		String[] stringDividida = termo_link.split(linkconceito);
	      		
	      		String termo_id = stringDividida[1];
	      		String superclass_link;
	      		if (superclasslink == null)	{ superclass_link = linkconceito + "RAIZ";} else {superclass_link = superclasslink.toString();}
	      		String[] stringDividida2 = superclass_link.split(linkconceito);
	      		String superclass_id;
	      		if (stringDividida2.length == 1){superclass_id = "RAIZ"; } else { superclass_id = stringDividida2[1];};
	      			
	       		
	      			
	      	
	      	
	      		
	      		//INSERE O REGISTRO
	      		//////////////////////////////////////////////////////////////////
	      		Hierarquia.existe(name, termo_id1, superclass_id1);
			  		
	      		if (Hierarquia.existe(name, termo_id1, superclass_id1)  == false )  { 		
			  		
	      		//	System.out.println("---INSERINDO STGONTOLOGIA: " + termo_id1 + " - " + superclass_id1);
			  		
	      		String sql = "INSERT INTO STGONTOLOGIA (TERMO_ID, TERMO_LABEL, TERMO_LINK, SUPERCLASS_ID, SUPERCLASS_LINK, ONTOLOGIA) VALUES (?, ?, ?, ?, ?, ?)";
	      	    
	      		PreparedStatement pstm = c.prepareStatement(sql);
	      		
				pstm.setString(1,termo_id);
				pstm.setString(2, descricao);
				pstm.setString(3, termo_link);
				pstm.setString(4, superclass_id);
				pstm.setString(5, superclass_link);
				pstm.setString(6, name);
				
				pstm.execute();
				c.commit();
				pstm.close();
				  
			
			  	}
				//else {System.out.println("------------------------------CLASSE: " + termo_id + " E SUBCLASSE: " + superclass_id + " EXISTEM");}
				 
	        }
	        
	        qe.close();
	        c.commit();
	        c.close();
	        
	        }
	        
	        
	        
		    }//else {System.out.println("------------------------------CLASSE: " + termo_id1 + " E SUBCLASSE: " + superclass_id1 + " EXISTEM");}
	  		
	  		
		} // FIM VERIFICA SE O TERMO E SUA SUPER CLASSE EXISTEM
	        
		}
		} catch (Exception e) {
		System.out.println(e); }

		



	}	
	
	
}
