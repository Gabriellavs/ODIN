
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.NoSuchElementException;

//import java.util.Scanner;


public class HerancaMultipla {


public static void main(String[] args) throws Exception {
	
		
		
		//PropertyConfigurator.configure("C:/Users/pc/workspace/JENA/src/log4j.properties");
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		Statement stmt = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;
		Statement stmt7 = null;
		
	   // System.out.println("------INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		   //   System.out.println("---Conectado com Sucesso");
	          stmt = c.createStatement(); 
	          stmt1 = c.createStatement();
	          stmt2 = c.createStatement();
	          stmt3 = c.createStatement();
	          stmt4 = c.createStatement();
	          stmt5 = c.createStatement();
	          stmt6 = c.createStatement();
	          stmt7 = c.createStatement();
	          
	       //   System.out.println("---IN�CIO DA ELIMINA��O DA DUPLA HERAN�A MULTIPLA");
	          
	          // INICIO SELECIONA CONCEITOS COM DUPLA HERAN�A MULTIPLA ------------------------------------------------------------------------ 
	          
	      
	          
	         ResultSet rsqry = stmt.executeQuery( "select idconceito, count(*) from stgdimontologica group by idconceito having count(*) > 1");

	          
	         // System.out.println("---INICIO DA EXTRA��O DE TERMOS");	
	     
			  if (rsqry.next() == false) {
	           //   System.out.println("---N�O H� CONCEITOS COM HERAN�A MULTIPLA");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  
	        			  String conceito = rsqry.getString("idconceito");
	        			  
	        			//  System.out.println("----------------------INICIO DA ATRIBUI��O DE PESO AO CONCEITO POR RELEV�NCIA DE HIERARQUIA: " + conceito);
	        			  
	        			  ////////////////////////////////
	        			  
	        			  ResultSet rsqry1 = stmt1.executeQuery("Select id, idconceito , idconceitopai from stgdimontologica WHERE idconceito = '" + conceito + "'");
	        			  
	        			  if (rsqry1.next() == true)  {
	        	        	  
	        	        	  do {
	        	        		  try {
	        	        			  
	        	        			  int idonto = rsqry1.getInt("id");
	        	        			  String conceitofilho = rsqry1.getString("idconceito");
	        	        			  String conceitopai = rsqry1.getString("idconceitopai");
	        	        			  
	        	        			  ////////////////////////////////////////////////////// ATRIBUI��O DO PESO
	        	        			  
	        	        			  ResultSet rsqry2 = stmt2.executeQuery("Select  sum(nivel) as peso from ( WITH RECURSIVE hierarquia (idconceito, conceito, nivel) AS (SELECT idconceito, conceito, 1 AS nivel, idconceitopai FROM stgdimontologica WHERE idconceito = '" + conceito + "' and idconceitopai = '" + conceitopai + "' UNION ALL SELECT g.idconceito, g.conceito, c.nivel + 1 AS nivel, g.idconceitopai FROM stgdimontologica g INNER JOIN hierarquia c ON g.idconceito = c.idconceitopai) SELECT distinct nivel, conceito, idconceito, idconceitopai FROM hierarquia order by nivel desc) as dimonto ");
	        	        			  
	        	        			  if (rsqry2.next() == true)  {
	        	        	        	  
	        	        	        	  do {
	        	        	        		  try {
	        	        	        			  
	        	        	        			  int peso = rsqry2.getInt("peso");
	        	        	        			          	        	        			  
	        	        	        			  String sql = "UPDATE stgdimontologica SET peso = ? WHERE idconceito = ? AND idconceitopai = ? AND id = ? ";
	        	        	        			  PreparedStatement pstm = c.prepareStatement(sql);
	        	        	        	      		
	        	        	        					pstm.setInt(1,peso);
	        	        	        					pstm.setString(2,conceitofilho);
	        	        	        					pstm.setString(3,conceitopai);
	        	        	        					pstm.setInt(4,idonto);
	        	        	        				
	        	        	        					pstm.execute();
	        	        	        					c.commit();
	        	        	        					pstm.close(); 
	        	        	        					
	        	        	        					//System.out.println("---ATRIBUI��O DE PESO AO CONCEITO: " + idonto);
	        	        	        			  
	        	        	        		  }  
	        	        	        		  
	        	        	        		  catch (SQLException e) {
	        	      	            			//System.out.println("---ERRO NA ATRIBUI��O DE PESO AO CONCEITO: " + conceitofilho + "CONCEITO PAI: " + conceitopai);
	        	      	            			e.printStackTrace();
	        	      	            			return;
	        	      	              	  		}
	        	      	                		
	        	      	                		//System.out.println(sql);
	        	      	                		
	        	      	                      } while (rsqry2.next() != false);  
	        	        	        		  }
	        	        			  
	        	        			  /////////////////////////////////////////////////////
	        	        		  }  
	        	        		  
	        	        		  catch (SQLException e) {
	      	            		//	System.out.println("---ERRO NA ATRIBUI��O DE PESO AO CONCEITO: " + conceito);
	      	            			e.printStackTrace();
	      	            			return;
	      	              	  		}
	      	                		
	      	                		//System.out.println(sql);
	      	                		
	      	                      } while (rsqry1.next() != false);  
	        	        		  }
	        			  
	        			  //////////////////////////////////
	        			
	        			  
	        			 // System.out.println("---FIM DA ATRIBUI��O DE PESO AO CONCEITO POR RELEV�NCIA DE HIERARQUIA: " + conceito);
	    		
	        			  
	        			  
	        			  
	        			//  System.out.println("---INICIO DA EXCLUS�O DE LINK DE CONCEITOS PAI E FILHO POR RELEV�NCIA DE HIERARQUIA: " + conceito);
	        			  
	        			  ResultSet rsqry3 = stmt3.executeQuery("select id, idconceito , idconceitopai from stgdimontologica WHERE idconceito = '" + conceito + "' and peso not in (Select max(peso) from stgdimontologica WHERE idconceito = '" + conceito + "')");
	        			  
	        			  if (rsqry3.next() == true)  {
	        	        	  
	        	        	  do {
	        	        		  try {
	        	        			  
	        	        			  int idontodel = rsqry3.getInt("id");
	        	        			  String conceitofilhodel = rsqry3.getString("idconceito");
	        	        			  String conceitopaidel = rsqry3.getString("idconceitopai");
	        	        			          	        	        			  
	        	        			  String sql = "DELETE FROM stgdimontologica WHERE idconceito = ? AND idconceitopai = ? AND id = ? ";
	        	        			  PreparedStatement pstm = c.prepareStatement(sql);
	        	        	      		
	        	        			  
	        	        			  pstm.setString(1,conceitofilhodel);
	        	        			  pstm.setString(2,conceitopaidel);
	        	        			  pstm.setInt(3,idontodel);
	        	        				
	        	        			  pstm.execute();
	        	        			  c.commit();
	        	        			  pstm.close(); 
	        	        					
	        	        			//  System.out.println("---DELE��O DO LINK : " + idontodel);
	        	        			  
	        	        		  }  
	        	        		  
	        	        		  catch (SQLException e) {
	      	            			//System.out.println("---ERRO NA DELE��O DO LINK.");
	      	            			e.printStackTrace();
	      	            			return;
	      	              	  		}
	      	                		
	      	                	
	      	                		
	      	                      } while (rsqry3.next() != false);  
	        	        		  }
	        			  
	        			 // System.out.println("---FIM DA EXCLUS�O DE LINK DE CONCEITOS PAI E FILHO POR RELEV�NCIA DE HIERARQUIA: " + conceito);
	        			  
	       			
        			
	        			/////////////////////////////////////////////////////////////////////////////////
	        			///INICIO DA VERIFICA��O DE RELEV�NCIA POR QUANTIDADE DE FILHOS  
	        			
	        			  ResultSet rsqry4 = stmt4.executeQuery( "Select idconceitopai , count(*) as peso from stgdimontologica WHERE idconceitopai in (Select idconceitopai from stgdimontologica WHERE idconceito = '" + conceito + "' order by idconceitopai) group by idconceitopai");
	        	          
	        		     //  System.out.println("---INICIO DA ATRIBUI��O DE PESO AO CONCEITO POR RELEV�NCIA DE QUANTIDADE DE FILHOS: " + conceito);	
	        		     
	        			  if (rsqry4.next() == false) {
	        		           //  System.out.println("---N�O H� CONCEITOS COM RELEV�NCIA DE FILHOS");
	        		      } else {
	        		        	  
	        		        	  do {
		        	        		  try {
		        	        			  
		        	        			  int peso = rsqry4.getInt("peso");
		        	        			  String conceitopai1 = rsqry4.getString("idconceitopai");
		        	        			          	        	        			  
		        	        			  String sql = "UPDATE stgdimontologica SET peso = ? WHERE idconceito = ? AND idconceitopai = ?";
		        	        			  PreparedStatement pstm = c.prepareStatement(sql);
		        	        	      		
		        	        			  
		        	        			  pstm.setInt(1,peso);
		        	        			  pstm.setString(2,conceito);
		        	        			  pstm.setString(3,conceitopai1);
		        	        				
		        	        			  pstm.execute();
		        	        			  c.commit();
		        	        			  pstm.close(); 
	        	        					
		        	        			//  System.out.println("---CONCEITO COM RELEV�NCIA DE FILHOS : " + conceito + " Conceito Pai: " + conceitopai1 + " Peso: " + peso);
		        	        			  
		        	        		  }  
		        	        		  
		        	        		  catch (SQLException e) {
		      	            			//System.out.println("---ERRO NA DELE��O DO LINK.");
		      	            			e.printStackTrace();
		      	            			return;
		      	              	  		}
		      	                		
		      	                	
		      	                		
		      	                      } while (rsqry4.next() != false);
	        	  
	 	      					}	 
	        			  
	        		    //   System.out.println("---FIM DA ATRIBUI��O DE PESO AO CONCEITO POR RELEV�NCIA DE QUANTIDADE DE FILHOS: " + conceito);	        			  
	        			  
	        			//////////////////////////////////////////////////////////////////////////////////  
	        			  
	        			  
	        			  
	        			//  System.out.println("---INICIO DA EXCLUS�O DE LINK DE CONCEITOS PAI E FILHO POR RELEV�NCIA DE QUANTIDADE DE FILHOS: " + conceito);
	        			  
	        			  ResultSet rsqry5 = stmt5.executeQuery("select id, idconceito , idconceitopai from stgdimontologica WHERE idconceito = '" + conceito + "' and peso not in (Select max(peso) from stgdimontologica WHERE idconceito = '" + conceito + "')");
	        			  
	        			  if (rsqry5.next() == true)  {
	        	        	  
	        	        	  do {
	        	        		  try {
	        	        			  
	        	        			  int idontodel = rsqry5.getInt("id");
	        	        			  String conceitofilhodel = rsqry5.getString("idconceito");
	        	        			  String conceitopaidel = rsqry5.getString("idconceitopai");
	       	        			          	        	        			  
	        	        			  String sql = "DELETE FROM stgdimontologica WHERE idconceito = ? AND idconceitopai = ? AND id = ? ";
	        	        			  PreparedStatement pstm = c.prepareStatement(sql);
	        	        	      		
	        	        			  
	        	        			  pstm.setString(1,conceitofilhodel);
	        	        			  pstm.setString(2,conceitopaidel);
	        	        			  pstm.setInt(3,idontodel);
	        	        				
	        	        			  pstm.execute();
	        	        			  c.commit();
	        	        			  pstm.close(); 
	        	        					
	        	        			//  System.out.println("---DELE��O DO LINK : " + idontodel);
	        	        			  
	        	        		  }  
	        	        		  
	        	        		  catch (SQLException e) {
	      	            		//	System.out.println("---ERRO NA DELE��O DO LINK.");
	      	            			e.printStackTrace();
	      	            			return;
	      	              	  		}
	      	                		
	      	                	
	      	                		
	      	                      } while (rsqry5.next() != false);  
	        	        		  }
	        			  
	        			//  System.out.println("---FIM DA EXCLUS�O DE LINK DE CONCEITOS PAI E FILHO POR RELEV�NCIA DE QUANTIDADE DE FILHOS: " + conceito);
	        			  

	        			  //////////////////////////////////////////////////////
	        			  

		        			/////////////////////////////////////////////////////////////////////////////////
		        			///INICIO DA VERIFICA��O DE RELEV�NCIA POR ORDEM ALFAB�TICA  
		        			
	        			//  System.out.println("---INICIO DA ATRIBUI��O DE PESO POR RELEV�NCIA ALFABETICA: " + conceito);
	        			  
		        			  ResultSet rsqry6 = stmt6.executeQuery( "Select id, idconceito , idconceitopai, peso from stgdimontologica WHERE idconceito = '" + conceito + "' order by idconceitopai asc");
		        	          
		        			  int pesoalfabetico = 1;
		        			  
		        		     
		        		     
		        			  if (rsqry6.next() == false) {
		        		         //    System.out.println("---N�O H� CONCEITOS COM RELEV�NCIA DE FILHOS");
		        		      } else {
		        		        	  
		        		        	  do {
			        	        		  try {
			        	        			  
			        	        			  int peso = pesoalfabetico;
			        	        			  int id = rsqry6.getInt("id");
			        	        			  String conceitopai6 = rsqry6.getString("idconceitopai");
			        	        			          	        	        			  
			        	        			  String sql = "UPDATE stgdimontologica SET peso = ? WHERE idconceito = ? AND idconceitopai = ? AND ID = ?";
			        	        			  PreparedStatement pstm = c.prepareStatement(sql);
			        	        	      		
			        	        			  
			        	        			  pstm.setInt(1,peso);
			        	        			  pstm.setString(2,conceito);
			        	        			  pstm.setString(3,conceitopai6);
			        	        			  pstm.setInt(4,id);
			        	        				
			        	        			  pstm.execute();
			        	        			  c.commit();
			        	        			  pstm.close(); 
			        	        					
			        	        		//	  System.out.println("---CONCEITO COM RELEV�NCIA ALFABETICA : " + conceito + " Conceito Pai: " + conceitopai6 + " Peso: " + peso);
			        	        			  
			        	        		  }  
			        	        		  
			        	        		  catch (SQLException e) {
			      	            		//	System.out.println("---ERRO NA DELE��O DO LINK.");
			      	            			e.printStackTrace();
			      	            			return;
			      	              	  		}
			      	                		
			        	        		  pesoalfabetico = pesoalfabetico + 1;
			      	                		
			      	                      } while (rsqry6.next() != false);
		        	  
		 	      					}	  
		        			  
		        			//  System.out.println("---FIM DA ATRIBUI��O DE PESO POR RELEV�NCIA ALFABETICA: " + conceito); 
		        			////////////////////////////////////////////////////////////////////////////////// 	        			  	        			  
	        			  

			        			//////////////////////////////////////////////////////////////////////////////////  
		        			  
		        			  
		        			  
		        			//  System.out.println("---INICIO DA EXCLUS�O DE LINK DE CONCEITOS PAI E FILHO POR RELEV�NCIA ALFAB�TICA: " + conceito);
		        			  
		        			  ResultSet rsqry7 = stmt7.executeQuery("select id, idconceito , idconceitopai from stgdimontologica WHERE idconceito = '" + conceito + "' and peso not in (Select min(peso) from stgdimontologica WHERE idconceito = '" + conceito + "')");
		        			  
		        			  if (rsqry7.next() == true)  {
		        	        	  
		        	        	  do {
		        	        		  try {
		        	        			  
		        	        			  int idontodel7 = rsqry7.getInt("id");
		        	        			  String conceitofilhodel7 = rsqry7.getString("idconceito");
		        	        			  String conceitopaidel7 = rsqry7.getString("idconceitopai");
		        	        			          	        	        			  
		        	        			  String sql = "DELETE FROM stgdimontologica WHERE idconceito = ? AND idconceitopai = ? AND id = ? ";
		        	        			  PreparedStatement pstm = c.prepareStatement(sql);
		        	        	      		
		        	        			  
		        	        			  pstm.setString(1,conceitofilhodel7);
		        	        			  pstm.setString(2,conceitopaidel7);
		        	        			  pstm.setInt(3,idontodel7);
		        	        				
		        	        			  pstm.execute();
		        	        			  c.commit();
		        	        			  pstm.close(); 
		        	        					
		        	        			//  System.out.println("---DELE��O DO LINK : " + idontodel7);
		        	        			  
		        	        		  }  
		        	        		  
		        	        		  catch (SQLException e) {
		      	            		//	System.out.println("---ERRO NA DELE��O DO LINK.");
		      	            			e.printStackTrace();
		      	            			return;
		      	              	  		}
		      	                		
		      	                	
		      	                		
		      	                      } while (rsqry7.next() != false);  
		        	        		  }
		        			  
		        			//  System.out.println("----------------------FIM DA EXCLUS�O DE LINK DE CONCEITOS PAI E FILHO POR RELEV�NCIA ALFAB�TICA: " + conceito);
		        			  

		        			  //////////////////////////////////////////////////////
		        			  
		        			  
		        			  
		        			  
	        			  
	        			  
	        		  }  catch (SQLException e) {
	            		//	System.out.println("---ERRO NO TRATAMENTO DE CONCEITOS COM DUPLA HERAN�A MULTIPLA");
	            			e.printStackTrace();
	            			rsqry.close();
	            			return;
	              	  }
	                		
	                 
	                		
	             } while (rsqry.next() != false);
	        	  
	 	      }	
	   
			  
	          
	        
	        //  System.out.println("---FIM DA ELIMINA��O DA DUPLA HERAN�A MULTIPLA"); 
	          rsqry.close();
              
		   } catch (NoSuchElementException e) {
		   			}
    
	   
		 
        stmt.close();
        stmt1.close();
        stmt2.close();
        stmt3.close();
        stmt4.close();
        stmt5.close();
        stmt6.close();
        stmt7.close();
        
        c.close();  
        
	  //  System.out.println("------FIM CONEX�O POSTGRES");
			}
	
	
}
