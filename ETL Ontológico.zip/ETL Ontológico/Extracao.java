


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.NoSuchElementException;

//import java.util.Scanner;

//import java.io.*;

//import org.apache.log4j.PropertyConfigurator;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

public class Extracao {

	
	public static String tfidfperson;
	public static String profundidade;
	public static String niveldimensao;
	
	public static void main(String[] args) throws Exception {
	
		
		
		lerXML();
		
	    
	    
	} // CLASSE MAIN
  
	
	
	
	// CLASSE LEITURA DO XML DE CONFIGURA��O
	
private static void lerXML() throws Exception{
		File fXmlFile = new File("c:\\configODIN.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		
		
		NodeList personalizacao = doc.getElementsByTagName("odin");
		
		Element person = (Element) personalizacao.item(0);
		String execucao = person.getElementsByTagName("execucao").item(0).getTextContent();
		tfidfperson = person.getElementsByTagName("tfidf").item(0).getTextContent();
		profundidade = person.getElementsByTagName("profundidade").item(0).getTextContent();
		niveldimensao = person.getElementsByTagName("niveldimensao").item(0).getTextContent();
		
		
		if (execucao == "C"){
			
		//System.out.println("Leitura do Arquivo de Configura��o: " + doc.getDocumentElement().getNodeName());
		NodeList nList = doc.getElementsByTagName("ontology");
		
		//System.out.println("----------------------------");
		//System.out.println("Quantidade de n�s :" + nList.getLength());
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				System.out.println("Id : " + (temp+1));
				System.out.println("Ontologia: " + eElement.getElementsByTagName("name").item(0).getTextContent());
				System.out.println("Arquivo: " + eElement.getElementsByTagName("file").item(0).getTextContent());
				System.out.println("Link: " + eElement.getElementsByTagName("link").item(0).getTextContent());
				System.out.println("Prefixo: " + eElement.getElementsByTagName("prefix").item(0).getTextContent());
				System.out.println("SubSTR Conceito: " + eElement.getElementsByTagName("substr").item(0).getTextContent());
				
				
				String name = eElement.getElementsByTagName("name").item(0).getTextContent();
				String nomeonto = eElement.getElementsByTagName("file").item(0).getTextContent();
				String linkconceito = eElement.getElementsByTagName("link").item(0).getTextContent();
				String prefixo = eElement.getElementsByTagName("prefix").item(0).getTextContent();
				String substr = eElement.getElementsByTagName("substr").item(0).getTextContent();
				
				
				//System.out.println("In�cio da Extra��o da Ontologia: " + nomeonto);
				Extracao( name, nomeonto,  linkconceito,  prefixo, substr); 
				//System.out.println("Fim da Extra��o da Ontologia: " + nomeonto);
				
			}
			
			
		}
	
		// CALCULO DO TF-IDF
        TFIDF tfidf = new TFIDF();
        tfidf.main(null);
        
		}
		
		
		
		
		//System.out.println("In�cio da Carga da Dimens�o Ontol�gica");
		Carga(); 
		//System.out.println("Fim da Carga da Dimens�o Ontol�gica");
		
		
	// FIM DA CLASSE LEITURA DO XML DE CONFIGURA��O	
		
		
	}
	
	
	private static void Extracao(String name, String nomeonto, String linkconceito, String prefixo, String substr) throws Exception{
		
		int Contador = 0;
		int ContadorSP = 0;
		
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;
		Statement stmt20 = null;
		Statement stmt21 = null;
		Statement stmt22 = null;
		Statement stmt23 = null;
		
		//String Ontologia = "MoleculeRole";
		//String nomeonto = "";
		//String linkconceito = "";
		//String prefixo = "";
		
		
		//Date data = new Date();
	    //System.out.println(data);
	   
	   
	    
	    //System.out.println("------INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      //c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tapdm","postgres", "admin");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		     // System.out.println("---Conectado com Sucesso");
	          stmt = c.createStatement();
	         // stmt2 = c.createStatement();
	         // stmt3 = c.createStatement();
	         // stmt20 = c.createStatement();
	        
	          
	          
	          String sqldeletestgconceito = "DELETE from stgconceito";
	          stmt.executeUpdate(sqldeletestgconceito);
	          
	          String sqldeletestg = "DELETE from stgontologia";
	          stmt.executeUpdate(sqldeletestg);
	          
	          String sqldeletedimonto = "DELETE from stgdimontologica";
	          stmt.executeUpdate(sqldeletedimonto);
	          
	          c.commit();
	          
	  	  
	  	    
	  	    // INICIO SELECIONA TERMOS DA ANOTA��O------------------------------------------------------------------------ 
	         
	          stmt = c.createStatement();
	         
	         
	          ResultSet rsqry = stmt.executeQuery( "SELECT DISTINCT IDCLASSE, termo FROM STGANOTACAO where ontologia = '" + name + "' and IDCLASSE  LIKE " + substr + " and IDCLASSE not in(select distinct termo_id from stgontologia where ontologia = '" + name + "') ORDER BY IDCLASSE"); 
          
	          //System.out.println("---INICIO DA EXTRA��O DE TERMOS");	
	     
			  if (rsqry.next() == false) {
	             // System.out.println("---N�O H� TERMOS A SEREM EXTRA�DOS");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			//  System.out.println(rsqry.getString("IDCLASSE"));
	        			  String termo = rsqry.getString("IDCLASSE");
	        			  String conceitolbl = rsqry.getString("termo").toUpperCase();
	        			 
	        			  
	        			  ExtraiConceito anotacao = new ExtraiConceito();
        				  anotacao.anota(termo, conceitolbl, name, nomeonto, linkconceito, prefixo);
	        			  
	        			  
	    		
	        		  }  catch (SQLException e) {
	            		//	System.out.println("---ERRO NA EXTRA��O DOS TERMOS");
	            			e.printStackTrace();
	            			return;
	            			
	              	  }
	                		
	                		
	                		
	                      } while (rsqry.next() != false);
	          
	 	      }	
	   
		
			  rsqry.close();
	          stmt.close();
	          //c.close();  
	           
	         // System.out.println("------FIM DA EXTRA��O DE TERMOS");  
 	        
	         // System.out.println("------INICIO DA EXTRA��O DE SUPERCLASSES"); 
	           
	          stmt6 = c.createStatement();
	          ResultSet rsqry10 = stmt6.executeQuery( "SELECT count(distinct(stg.superclass_id)) as QTD  FROM stgontologia stg where (ontologia = '" + name + "') and (stg.superclass_id <> 'RAIZ' AND stg.superclass_id IS NOT NULL) AND (stg.superclass_id NOT IN (SELECT termo_id  FROM stgontologia where ontologia = '" + name + "')) AND stg.superclass_id NOT IN (SELECT conceito  FROM stgconceito)  ;");
	          rsqry10.next();
	          ContadorSP = rsqry10.getInt("QTD");
	        //  System.out.println("---CONTADOR DE SUPERCLASSES: " + ContadorSP);
	          rsqry10.close();
	          stmt6.close();
	            
	          
	          
	          if (ContadorSP == 0 ) {
	          //    System.out.println("---N�O H� SUPERCLASSES A SEREM EXTRA�DAS");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  
	        			  	        			  
	        			  Hierarquia hierq = new Hierarquia();
	                      hierq.hierarquia(name, nomeonto, linkconceito, prefixo); 
	                      
	                      if (ContadorSP == 1 ) {
	        	              
	                    	  stmt6 = c.createStatement();
	            	          ResultSet rsqry11 = stmt6.executeQuery( "SELECT count(distinct(stg.superclass_id)) as QTD  FROM stgontologia stg where (ontologia = '" + name + "') and  (stg.superclass_id <> 'RAIZ' AND stg.superclass_id IS NOT NULL) AND (stg.superclass_id NOT IN (SELECT termo_id  FROM stgontologia where ontologia = '" + name + "')) AND stg.superclass_id NOT IN (SELECT conceito  FROM stgconceito);");
	            	          rsqry11.next();
	            	          ContadorSP = rsqry11.getInt("QTD");
	            	        //  System.out.println("---QUANTIDADE DE SUPERCLASSES A SEREM EXTRA�DAS: " + ContadorSP);
	            	          rsqry11.close();
	            	          stmt6.close();
	            	          
	        	          } else { ContadorSP --; }
	                      
	                      
	        		  }  catch (SQLException e) {
	            		//	System.out.println("---ERRO NA EXTRA��O DAS SUPERCLASSES");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                	
	                } while (ContadorSP != 0);
	          
	 	      }	
	   
		            
              
            //  System.out.println("------FIM DA EXTRA��O DE SUPERCLASSES");
	         

	          
              
		   } catch (NoSuchElementException e) {
		   			}
    
	
	}

	
//////////////////////////////////////////////
	
	private static void Carga() throws Exception{
		
			
		//	CONEX�O COM O BANCO DE DADOS
				
		Connection c = null;
		
		Statement stmt0 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;
		Statement stmt20 = null;
		Statement stmt21 = null;
		Statement stmt22 = null;
		Statement stmt23 = null;
		Statement stmt24 = null;
		Statement stmt30 = null;
		
	  //  System.out.println("------INICIO CONEX�O POSTGRES");
	    
	   
	    try {
	    	  
		      Class.forName("org.postgresql.Driver");
		      c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cen1","postgres", "admin");
		      c.setAutoCommit(false);
		      System.out.println("---Conectado com Sucesso");
	          
		      stmt0 = c.createStatement();
	          stmt2 = c.createStatement();
	          stmt3 = c.createStatement();
	          stmt20 = c.createStatement();

	          
              System.out.println("------INICIO DA CARGA DA STAGE ONTOLOGICA");
  
              	// VERIFICA AS ONTOLOGIAS PARA CARGA
              ResultSet rsqry0 = stmt0.executeQuery( "select distinct (ontologia) from stgontologia");     
              
              if (rsqry0.next() == false) {
	              System.out.println("---N�O H� INSTANCIAS ONTOL�GICAS");
	          } else {
              
	          do {
	          try {  
	        
	        	  
	          String ontologiacarga = rsqry0.getString("ontologia");
	          System.out.println("Carregando: " + ontologiacarga);
	          
	          stmt2 = c.createStatement();
	          
              // QUERY ANTERIOR SEM O TFIDF
	          // ResultSet rsqry2 = stmt2.executeQuery( "SELECT  ontologia, categoria, termo_id, termo_label, superclass_id FROM stgontologia where termo_id NOT in (SELECT termo_id FROM stgontologia where termo_id NOT in (select superclass_id from stgontologia) and superclass_id = 'RAIZ')");
	        
              // SELECIONA OS TERMOS MAIS RELEVANTES ATRAVES DO CALCULO TF-IDF
              ResultSet rsqry2 = stmt2.executeQuery( "SELECT  termo_id, superclass_id FROM stgontologia where ontologia = '" + ontologiacarga + "' and  termo_id IN (select distinct conceito from stgtfidf where tfidf >= " + tfidfperson + " ) and termo_id NOT in (SELECT termo_id FROM stgontologia where termo_id NOT in (select superclass_id from stgontologia) and superclass_id = 'RAIZ')");
              
              
			  if (rsqry2.next() == false) {
	              System.out.println("---1 - N�O H� DADOS PARA CARREGAR A DIMENS�O ONTOL�GICA");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  String idconceito1 = rsqry2.getString("termo_id");
	        			  
	        			  // SELECIONA A HIERARQUIA DOS TERMOS RELEVANTES PARA INSERIR NA DIMENS�O ONTOLOICA
	        			  ResultSet rsqry20 = stmt20.executeQuery( "Select distinct conceito,id, idpai, ontologia, categoria  from (WITH RECURSIVE hierarquia (termo_id,termo_label,nivel) AS (SELECT stg.termo_id, stg.termo_label, 1 AS nivel, stg.superclass_id, stg.ontologia, stg.categoria FROM stgontologia stg WHERE stg.ontologia = '" + ontologiacarga + "' and stg.termo_id = '"+ idconceito1 + "'  UNION ALL SELECT g.termo_id, g.termo_label, c.nivel + 1 AS nivel, g.superclass_id, g.ontologia, g.categoria  FROM stgontologia g INNER JOIN hierarquia c ON g.termo_id = c.superclass_id and g.ontologia = '" + ontologiacarga + "' and c.ontologia = '" + ontologiacarga + "' ) SELECT distinct nivel, hierq.termo_label as conceito, hierq.termo_id as id, hierq.superclass_id as idpai, hierq.ontologia, hierq.categoria  FROM hierarquia hierq where ontologia = '" + ontologiacarga + "'  order by nivel desc) dimonto where (id, idpai) not in (select idconceito, idconceitopai from stgdimontologica where ontologia = '" + ontologiacarga + "' ) order by id, idpai");
	        			  
	        			  if (rsqry20.next() == false) {
	        	             // System.out.println("---2 - N�O H� DADOS PARA CARREGAR A DIMENS�O ONTOL�GICA: " + idconceito1);
	        	         
	        			  } else {
	        	        	  
	        	        	  do {
	        	        		  try {
	        			  
	        	        	    String idconceito = rsqry20.getString("id");	  
	        			  		String idconceitopai = rsqry20.getString("idpai");
	        			  		String ontologia = rsqry20.getString("ontologia");
	        			  		String categoria = rsqry20.getString("categoria");
	        			  		String conceito = rsqry20.getString("conceito");
	        			  
	        			  		String sql = "INSERT INTO stgdimontologica ( ontologia, categoria, idconceito, conceito, idconceitopai) VALUES ( ?, ?, ?, ?, ?)";
	        		  
	        			  
	        			  
	        			  		PreparedStatement pstm = c.prepareStatement(sql);
	        	      		
	        			  		pstm.setString(1,ontologia);
	        			  		pstm.setString(2, categoria);
	        			  		pstm.setString(3, idconceito);
	        			  		pstm.setString(4, conceito);
	        			  		pstm.setString(5, idconceitopai);
	        				
	        				
	        				
	        			  		pstm.execute();
	        			  		c.commit();
	        			  		pstm.close();
	        			 
        		  		    	
	        	        		  }  catch (SQLException e) {
	      	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
	      	            			e.printStackTrace();
	      	            			return;
	      	              	  		}
	      	                		
	      	                		//System.out.println(sql);
	      	                		
	      	                      } while (rsqry20.next() != false);
	      	          
	      	 	      }	
	        			  		
	        			  		
	        			  		
	        			  		
	        		  }  catch (SQLException e) {
	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                		//System.out.println(sql);
	                		
	              } while (rsqry2.next() != false);
	          
	 	      }	
	   
			  c.commit();
			  rsqry2.close();
	          stmt2.close();
           
	          System.out.println("------FIM DA CARGA DA STAGE ONTOLOGICA");  
	          
	          // CHAMADA A EXCLUS�O DA HerancaMultipla
	          
	          HerancaMultipla dupla = new HerancaMultipla();
              dupla.main(null);
          
	          System.out.println("------INICIO DA DEFINI��O DE N�VEIS");
             
              stmt4 = c.createStatement();
	          
   	          ResultSet rsqry4 = stmt4.executeQuery( "WITH RECURSIVE hierarquia (idconceito,conceito,nivel) AS (SELECT idconceito, conceito, 1 AS nivel, idconceitopai, ontologia from stgdimontologica where ontologia = '" + ontologiacarga + "'  and idconceitopai = 'RAIZ' and idconceito in (select distinct idconceitopai FROM stgdimontologica where ontologia = '" + ontologiacarga + "' ) UNION ALL SELECT g.idconceito, g.conceito, c.nivel + 1 AS nivel, g.idconceitopai, g.ontologia FROM stgdimontologica g INNER JOIN hierarquia c ON g.idconceitopai = c.idconceito and g.ontologia = '" + ontologiacarga + "' and c.ontologia = '" + ontologiacarga + "' ) SELECT distinct nivel, conceito, idconceito as id, idconceitopai as idpai FROM hierarquia where ontologia = '" + ontologiacarga + "'  order by nivel");
              
   	          if (rsqry4.next() == false) {
	              System.out.println("---N�O H� TERMOS NA HIERARQUIA");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  //System.out.println(rsqry.getString("IDCLASSE"));
	        			  int nivel = rsqry4.getInt("nivel");
	        			  String conceito = rsqry4.getString("conceito");
	        			  String id = rsqry4.getString("id");
	        			  String idpai = rsqry4.getString("idpai");
	        			  
	        			  String sql = "UPDATE stgdimontologica SET NIVEL = ? WHERE IDconceito = ? AND IDconceitopai = ? and conceito = ? and ontologia = ? ";
	        			  PreparedStatement pstm = c.prepareStatement(sql);
	        	      		
	        					pstm.setInt(1,nivel);
	        					pstm.setString(2, id);
	        					pstm.setString(3, idpai);
	        					pstm.setString(4, conceito);
	        					pstm.setString(5, ontologiacarga);
	        				
	        				
	        					pstm.execute();
	        					c.commit();
	        					pstm.close(); 
	        				
	    		
	        		  }  catch (SQLException e) {
	            			System.out.println("---ERRO HIERARQUIA");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                		
	                		
	                      } while (rsqry4.next() != false);
	          
	 	      }	
	   
			 
			  rsqry4.close();
	         // stmt4.close();
	          
			  System.out.println("------FIM DA DEFINI��O DE N�VEIS");
			  
		
			  System.out.println("------INICIO DA CARGA DA DIMENS�O ONTOLOGICA");
              
              stmt21 = c.createStatement();
              
	          
              
              // SELECIONA DO PRIMEIRO NIVEL EM Y NIVEIS
              niveldimensao = niveldimensao + 1;
              
              ResultSet rsqry21 = stmt21.executeQuery( "Select * from stgdimontologica  where nivel > " + niveldimensao + " and ontologia = '" + ontologiacarga + "' and nivel between (select min (nivel) from (select idconceito, idconceitopai, nivel from stgdimontologica where ontologia = '" + ontologiacarga + "' and idconceito in ( select idconceitopai from stgdimontologica where ontologia = '" + ontologiacarga + "' )) nivel) and ( select (min (nivel) + ( " + profundidade + " -1)) as max from (select idconceito, idconceitopai, nivel from stgdimontologica where ontologia = '" + ontologiacarga + "' and idconceito in (select idconceitopai from stgdimontologica where ontologia = '" + ontologiacarga + "')) nivel) ");
	     
			  if (rsqry21.next() == false) {
	              System.out.println("---1 - N�O H� DADOS PARA CARREGAR A DIMENS�O ONTOL�GICA");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			String idconceito1 = rsqry21.getString("idconceito");
	        			String idconceitopai1 = rsqry21.getString("idconceitopai");
      			  		String ontologia1 = rsqry21.getString("ontologia");
      			  		String categoria1 = rsqry21.getString("categoria");;
      			  		String conceito1 = rsqry21.getString("conceito");
      			  		
      			  
      			  		String sql = "INSERT INTO dimontologica ( ontologia, categoria, idconceito, conceito, idconceitopai) VALUES ( ?, ?, ?, ?, ?)";
      		  
      			  
      			  
      			  		PreparedStatement pstm = c.prepareStatement(sql);
      	      		
      			  		pstm.setString(1,ontologia1);
      			  		pstm.setString(2, categoria1);
      			  		pstm.setString(3, idconceito1);
      			  		pstm.setString(4, conceito1);
      			  		pstm.setString(5, idconceitopai1);
      			  		
      				
      				
      			  		pstm.execute();
      			  		c.commit();
      			  		pstm.close();
      			 
	        					
	        			  		
	        		  }  catch (SQLException e) {
	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
	            			e.printStackTrace();
	            			return;
	              	  }
	           	                		
	                } while (rsqry21.next() != false);
	          
	 	      }	
	   
			  c.commit();
			  rsqry21.close();
	          stmt21.close();
	            
	          
              
              
              stmt22 = c.createStatement();
              stmt23 = c.createStatement();
              stmt24 = c.createStatement();
              
              // SELECIONA OS CONCEITOS COM MAIOR NIVEL PARA BUSCAR SEUS FOLHAS QUERY ANTERIOR
              ResultSet rsqry22 = stmt22.executeQuery( "SELECT idconceito FROM  stgdimontologica where ontologia = '" + ontologiacarga + "' and nivel in (SELECT min(nivel) FROM  stgdimontologica where ontologia = '" + ontologiacarga + "') ORDER BY IDCONCEITO");
	     
	     	
			  if (rsqry22.next() == false) {
	              System.out.println("---2 - N�O H� DADOS PARA CARREGAR A DIMENS�O ONTOL�GICA");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			
	        			 
	        			String idconceito1 = rsqry22.getString("idconceito");
	        			
	        			
	        			
	                    ///////A PARTIR DAS CATEGORIAS INSERIDAS NA DIMONTOLOGICA, BUSQUE O MAIOR NIVEL PARA LIGAR OS CONCEITOS FOLHAS
	        			ResultSet rsqry24 = stmt24.executeQuery( "select idconceito from  (SELECT stg.idconceito , conceito, 1 AS nivel, stg.idconceitopai, stg.ontologia   FROM dimontologica stg where stg.ontologia = '" + ontologiacarga + "' and stg.idconceito  =  '" + idconceito1 + "' UNION ALL (WITH RECURSIVE hierarquia (idconceito,conceito, nivel, idconceitopai, ontologia) AS (  SELECT stg.idconceito , conceito, 2 as nivel, stg.idconceitopai, stg.ontologia  FROM dimontologica stg where stg.ontologia = '" + ontologiacarga + "' and stg.idconceitopai =  '" + idconceito1 + "'   UNION ALL  SELECT o.idconceito, o.conceito, h.nivel + 1 as nivel, o.idconceitopai, o.ontologia FROM dimontologica o INNER JOIN hierarquia h ON h.idconceito  = o.idconceitopai and h.ontologia = '" + ontologiacarga + "' and o.ontologia = '" + ontologiacarga + "') SELECT DISTINCT idconceito, conceito, nivel, idconceitopai, ontologia FROM hierarquia where ontologia = '" + ontologiacarga + "' ORDER BY nivel asc)) as CATEGORIA where ontologia = '" + ontologiacarga + "' and nivel = 3");
	        		     
	      			    if (rsqry24.next() == false) {
	      	              System.out.println("---3 - N�O H� DADOS PARA CARREGAR A DIMENS�O ONTOL�GICA --" + idconceito1);
	      	            } else {
	      	        	  
	      	        	  do {
	      	        		  try {
	      	        			 
	      	        			  
	      	        			  	String idconceito2 = rsqry24.getString("idconceito");
	        			
	      	        			       	        			  
				        			//////////SELECIONA E INSERE OS CONCEITOS FOLHAS. OS CONCEITOS QUE EST�O NO MEIO DA HIERARQUIA E FORAM ANOTADOS S�O CONSIDERADOS PARA A HIERARQUIA 
				        			
				        			ResultSet rsqry23 = stmt23.executeQuery( "select * from stgdimontologica where ontologia = '" + ontologiacarga + "' and (idconceito ) not in (Select distinct idconceitopai from (WITH RECURSIVE hierarquia AS (SELECT stg.idconceito, stg.idconceitopai, stg.ontologia  FROM stgdimontologica stg where stg.ontologia = '" + ontologiacarga + "' and stg.idconceitopai = '" + idconceito2 + "'  UNION ALL SELECT o.idconceito, o.idconceitopai, o.ontologia FROM stgdimontologica o INNER JOIN hierarquia h ON h.idconceito = o.idconceitopai and h.ontologia = '" + ontologiacarga + "' and o.ontologia = '" + ontologiacarga + "') SELECT DISTINCT idconceito, idconceitopai, ontologia FROM hierarquia where ontologia = '" + ontologiacarga + "' ORDER BY idconceitopai, idconceito) folhas WHERE  IDCONCEITOPAI NOT IN (SELECT IDCLASSE FROM STGANOTACAO WHERE ONTOLOGIA = '" + ontologiacarga + "')) and idconceito in ( Select idconceito from (WITH RECURSIVE hierarquia AS (SELECT stg.idconceito, stg.idconceitopai, stg.ontologia  FROM stgdimontologica stg where stg.idconceitopai = '" + idconceito2 + "' UNION ALL SELECT o.idconceito, o.idconceitopai, o.ontologia FROM stgdimontologica o INNER JOIN hierarquia h ON h.idconceito = o.idconceitopai and h.ontologia = '" + ontologiacarga + "' and o.ontologia = '" + ontologiacarga + "') SELECT DISTINCT idconceito, idconceitopai FROM hierarquia where ontologia = '" + ontologiacarga + "' ORDER BY idconceitopai, idconceito) folhas) ORDER BY CONCEITO");
				        		     
				      			    if (rsqry23.next() == false) {
				      	              System.out.println("---3 - N�O H� CONCEITOS FOLHA PARA: " + idconceito2 + "A SEREM INSERIDOS");
				      	            } else {
				      	        	  
				      	        	  do {
				      	        		  try {
				      	        			  
				      	        			String idconceito = rsqry23.getString("idconceito");
				      	       
				      	        			String idconceitopai = rsqry23.getString("idconceitopai");
				          			  		String ontologia = rsqry23.getString("ontologia");
				          			  		String categoria = rsqry23.getString("categoria");
				          			  		String conceito = rsqry23.getString("conceito");
				          			  		
				          			  		String sql = "INSERT INTO dimontologica ( ontologia, categoria, idconceito, conceito, idconceitopai) VALUES ( ?, ?, ?, ?, ?)";
				      	        			
				      	        			PreparedStatement pstm = c.prepareStatement(sql);
				            	      		
				            			  	pstm.setString(1,ontologia);
				            			  	pstm.setString(2, categoria);
				            			  	pstm.setString(3, idconceito);
				            			  	pstm.setString(4, conceito);
				            			  	pstm.setString(5, idconceitopai);
				            				
				            								            				
				            			  	pstm.execute();
				            			  	c.commit();
				            			  	pstm.close();
				            			 	  		
				      	        		  }  catch (SQLException e) {
				      	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
				      	            			e.printStackTrace();
				      	            			return;
				      	              	  }
				      	                		
				      	                		
				      	                		
				      	              } while (rsqry23.next() != false);
				      	          
				      	 	         }	
				      			    	
				      			    //////////FIM SELECIONA E INSERE OS CONCEITOS FOLHAS	
				      			    
				      			    
				      			    //////////INICIO VERIFICA CONCEITO SEM PAI
				      			    

				      			    stmt30 = c.createStatement();
				      			  
				        			ResultSet rsqry30 = stmt30.executeQuery( "select * from dimontologica where ontologia = '" + ontologiacarga + "' and (idconceitopai ) not in (Select distinct idconceito from dimontologica where ontologia = '" + ontologiacarga + "') and idconceitopai <> ('RAIZ')");
				        		     
				      			    if (rsqry30.next() == false) {
				      	              System.out.println("---- N�O H� CONCEITOS SEM PAI");
				      	            } else {
				      	        	  
				      	        	  do {
				      	        		  try {
				      	        			  
				      	        			int id = rsqry30.getInt("id");
					  	        			String idconceito = rsqry30.getString("idconceito");
					  	        			String idconceitopai = idconceito2;
					  	        							          			  		
				          			  		String sql = "UPDATE dimontologica SET idconceitopai = ? WHERE IDconceito = ? and id = ? and ontologia = ?";
				          			  		PreparedStatement pstm = c.prepareStatement(sql);
				  	        	      		
				          			  		pstm.setString(1, idconceitopai);
				  	        				pstm.setString(2, idconceito);
				  	        				pstm.setInt(3, id);
				  	        				pstm.setString(4, ontologiacarga);
				  	        				
				  	        				pstm.execute();
				  	        				c.commit();
				  	        				pstm.close(); 
				            			  	
				            			  	
				            			 	  		
				      	        		  }  catch (SQLException e) {
				      	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
				      	            			e.printStackTrace();
				      	            			return;
				      	              	  }
				      	                		
				      	                						      	                		
				      	              } while (rsqry30.next() != false);
				      	          
				      	 	         }
				      			    
				      			    //////////FIM VERIFICA CONCEITO SEM PAI
	      			    
	      	        		}  catch (SQLException e) {
      	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
      	            			e.printStackTrace();
      	            			return;
      	              	  }
      	                		
      	                		
      	                		
      	              } while (rsqry24.next() != false);
      	          
      	 	         }
	      			    
	      			    
	      			    
	        		  }  catch (SQLException e) {
	            			System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                		
	                		
	              } while (rsqry22.next() != false);
	          
	 	      }	
	   
			  c.commit();
			  rsqry22.close();
	          stmt22.close();
	          
	          ///////// ATRIBUINDO ID PAI
	          
	          Statement stmt27 = null;
	          stmt27 = c.createStatement();
	          
	          ResultSet rsqry27 = stmt27.executeQuery( "select d.id, d.idconceito, d.idconceitopai, d2.id as idpai, d2.idconceito from dimontologica d, dimontologica d2 where d.idconceitopai = d2.idconceito and d.ontologia = '" + ontologiacarga + "' and d2.ontologia = '" + ontologiacarga + "'  ");
              
   	          if (rsqry27.next() == false) {
	              System.out.println("---N�O H� CONCEITOS A SEREM ATUALIZADOS");
	          } else {
	        	  
	        	  do {
	        		  try {
	        			  
	        			  
	        			  int id = rsqry27.getInt("id");
	        			  String idconceito = rsqry27.getString("idconceito");
	        			  String idconceitopai = rsqry27.getString("idconceitopai");
	        			  int idpai = rsqry27.getInt("idpai");
	        			  
	        			  
	        			  
	        			  String sql = "UPDATE dimontologica SET idpai = ? WHERE IDconceito = ? AND IDconceitopai = ? and id = ? and ontologia = ?";
	        			  PreparedStatement pstm = c.prepareStatement(sql);
	        	      		
	        					pstm.setInt(1,idpai);
	        					pstm.setString(2, idconceito);
	        					pstm.setString(3, idconceitopai);
	        					pstm.setInt(4, id);
	        					pstm.setString(5, ontologiacarga);
	        				
	        				
	        					pstm.execute();
	        					c.commit();
	        					pstm.close(); 
	        				
	    		
	        		  }  catch (SQLException e) {
	            			System.out.println("---ERRO NA ATRIBUI��O ID PAI");
	            			e.printStackTrace();
	            			return;
	              	  }
	                		
	                		
	                		
	                      } while (rsqry27.next() != false);
	          
	        	 
	        	  
	 	      }	
   	          c.commit();
   	          rsqry27.close();
   	          stmt27.close();
   	         ///////// FIM ATRIBUINDO ID PAI
   	          
	         
	          System.out.println("------FIM DA CARGA DA DIMENS�O ONTOLOGICA PARA ONTOLOGIA: " + ontologiacarga);
	          
	          
	       
	          }  catch (SQLException e) {
	          System.out.println("---ERRO NA CARGA DA DIMENSAO ONTOLOGICA");
	          e.printStackTrace();
	          return;
	          }
	                 		
	         } while (rsqry0.next() != false); 
	          
	         }///////FIM DE VERIFICA AS ONTOLOGIAS 
              
              
              
		   } catch (NoSuchElementException e) {
		   			}
    
	    
	    Date datafim = new Date();
	    System.out.println(datafim);
	    
	    c.close();;
	    
	    System.out.println("------FIM CONEX�O POSTGRES");
	   
	
		
	    	
		
	}
	
	
	
}
